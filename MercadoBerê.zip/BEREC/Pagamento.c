static void criarMenuPagamento(){

}